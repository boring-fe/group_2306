# JSON API

### Установка
Выполнить в терминале `npm install`
### Запуск
В терминале выполнить `npm start`

### роуты

<br />GET    /ads
<br /> GET    /ads/ads1
<br /> POST   /ads
<br /> PUT    /ads/ads1
<br />DELETE /ads/ads1

<br />GET    /posts
<br /> GET    /posts/ads1
<br /> POST   /posts
<br /> PUT    /posts/ads1
<br />DELETE /posts/ads1