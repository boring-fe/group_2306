import { createCircles } from "./circles.js";
const number = 100;
createCircles(number);
